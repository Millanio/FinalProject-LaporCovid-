<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <a href="lapor.php">Lapor Covid</a>
    <br>
    <a href="grafik.php">Lihat Grafik</a>
    <br>
    <a href="ekspor.php">Ekspor Data</a>
    <br>
    <a href="logout.php">logout</a>
    <br>
    <br><br>

    <a href="#">Ekspor PDF</a>
    <a href="#">Ekspor Excel</a>
  </body>
</html>
