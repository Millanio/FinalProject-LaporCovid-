<div class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1 class="m-0 text-dark">Grafik (<?= date("Y") ?>)</h1>
      </div><!-- /.col -->
    </div><!-- /.row -->
  </div><!-- /.container-fluid -->
</div>
<section class="content">
  <div class="container-fluid">
    <div class="card">
      <div class="card-body">
        <div class="chart">
          <canvas id="barChart" style="min-height: auto; height: 70vh; max-height: auto; max-width: auto;"></canvas>
        </div>
      </div>
      <!-- /.card-body -->
    </div>
  </div>
</section>
